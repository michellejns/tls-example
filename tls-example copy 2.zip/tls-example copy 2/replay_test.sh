#!/bin/bash

SERVER_LOG="server_log.txt"
CLIENT_LOG_1="client_log_1.txt"
CLIENT_LOG_2="client_log_2.txt"
CLIENT_LOG_3="client_log_3.txt"
PSK_CACHE="psk_cache.gob"
PSK_BACKUP="psk_cache_backup.gob"

echo "🧹 Alte Logs löschen..."
rm -f "$SERVER_LOG" "$CLIENT_LOG_1" "$CLIENT_LOG_2" "$CLIENT_LOG_3" "$PSK_BACKUP"


echo "🔁 [1/3] Erster Lauf: PSK erzeugen"
go run client/client.go | tee "$CLIENT_LOG_1"

if [[ ! -f "$PSK_CACHE" ]]; then
  echo "❌ PSK-Cache nicht gefunden! Abbruch."
  kill $SERVER_PID
  exit 1
fi

echo "💾 PSK-Cache sichern..."
cp "$PSK_CACHE" "$PSK_BACKUP"
kill $client_PID

echo "🚀 [2/3] Zweiter Lauf: 0-RTT mit echtem PSK"
go run client/client.go | tee "$CLIENT_LOG_2"

echo "♻️ [3/3] Dritter Lauf: Replay-Versuch (alter PSK wird zurückkopiert)"
cp "$PSK_BACKUP" "$PSK_CACHE"
DISABLE_PSK_PUT=1 go run client/client.go | tee "$CLIENT_LOG_3"


echo "🛑 Server manuell weiterlaufen lassen."


echo ""
echo "🕵️ Ergebnisprüfung:"
if grep -q "⚠️ Replay erkannt" "$SERVER_LOG"; then
  echo "✅ Replay wurde korrekt erkannt!"
else
  echo "❌ Replay wurde NICHT erkannt!"
fi
