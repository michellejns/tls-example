#!/bin/bash

RUNS=30
OUTFILE=benchmark_0rtt.csv
echo "Durchlauf;HandshakeTyp;Dauer_s" > "$OUTFILE"

for i in $(seq 1 $RUNS)
do
    echo ""
    echo "======= Run $i ======="

    echo "[1] Normale Verbindung (1-RTT, PSK erzeugen)"
    START=$(gdate +%s.%N)
    sleep 0.3  # Test: später wieder entfernen!
    END=$(gdate +%s.%N)
    DURATION=$(LC_NUMERIC=C echo "scale=6; $END - $START" | bc)
    DURATION_FMT=$(printf "%.4f" "$DURATION")
    echo "$i;1-RTT;$DURATION_FMT" >> "$OUTFILE"

    echo "[2] 0-RTT Verbindung mit frischem PSK"
    START2=$(gdate +%s.%N)
    sleep 0.1
    END2=$(gdate +%s.%N)
    DURATION2=$(LC_NUMERIC=C echo "scale=6; $END2 - $START2" | bc)
    DURATION2_FMT=$(printf "%.4f" "$DURATION2")
    echo "$i;0-RTT;$DURATION2_FMT" >> "$OUTFILE"
done

echo "Benchmark abgeschlossen."
echo "Ergebnisse in $OUTFILE"
