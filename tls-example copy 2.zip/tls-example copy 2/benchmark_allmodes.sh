#!/bin/bash

RUNS=30

# 1. Full Handshake (ohne PSK, ohne 0-RTT)
OUTFILE_FULL="benchmark_full.csv"
echo "Durchlauf;Typ;Dauer_s" > "$OUTFILE_FULL"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (Full Handshake) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=full > client_log_full.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;Full;$DURATION" >> "$OUTFILE_FULL"
done

# 2. 1-RTT Handshake (Initial handshake, PSK-Erzeugung)
OUTFILE_1RTT="benchmark_1rtt.csv"
echo "Durchlauf;Typ;Dauer_s" > "$OUTFILE_1RTT"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (1-RTT) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=init > client_log_1rtt.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;1-RTT;$DURATION" >> "$OUTFILE_1RTT"
done

# 3. 0-RTT ohne Replay-Detection/Puncturing
OUTFILE_0RTT_NO_REPLAY="benchmark_0rtt_no_replay.csv"
echo "Durchlauf;Typ;Dauer_s" > "$OUTFILE_0RTT_NO_REPLAY"
echo ">> Server im Modus OHNE Replay-Detection/Puncturing starten!"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (0-RTT ohne Replay/Puncturing) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=zeroRTTNoReplay > client_log_0rtt_norp.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;0-RTT_noReplayNoPuncture;$DURATION" >> "$OUTFILE_0RTT_NO_REPLAY"
done

# 4. 0-RTT mit Replay-Detection & Puncturing
OUTFILE_0RTT_REPLAY="benchmark_0rtt_replay.csv"
echo "Durchlauf;Typ;Dauer_s" > "$OUTFILE_0RTT_REPLAY"
echo ">> Server im Modus MIT Replay-Detection & Puncturing starten!"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (0-RTT mit Replay/Puncturing) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=zeroRTT > client_log_0rtt_rp.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;0-RTT_ReplayPuncture;$DURATION" >> "$OUTFILE_0RTT_REPLAY"
done

echo "Alle Benchmarks abgeschlossen. Einzelne Ergebnisse in:"
echo "  $OUTFILE_FULL"
echo "  $OUTFILE_1RTT"
echo "  $OUTFILE_0RTT_NO_REPLAY"
echo "  $OUTFILE_0RTT_REPLAY"