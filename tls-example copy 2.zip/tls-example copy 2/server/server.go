package main

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"crypto/x509/pkix"
	"fmt"
	"log"
	"math/big"
	"net"
	"time"

	"tls-example/pskmanager"

	"github.com/bits-and-blooms/bloom/v3"
	"github.com/michellejns/mint"
)

var usedPSKs = bloom.NewWithEstimates(1000, 0.001) // Platz für ca. 1000 PSKs, false positive rate 0.1%
var UsedPSKMgr = pskmanager.NewUsedPSKManager()

// für Latenztest
func handleEcho(conn net.Conn) {
	defer conn.Close()
	buf := make([]byte, 1024)
	for {
		n, err := conn.Read(buf)
		if err != nil {
			log.Println("Fehler beim Lesen:", err)
			return // Verbindung wird beendet
		}
		log.Println("Nachricht empfangen nach Handshake:", string(buf[:n]))
		_, err = conn.Write(buf[:n])
		if err != nil {
			log.Println("Fehler beim Schreiben:", err)
			return
		}
	}
}

func newSelfSigned(name string, alg mint.SignatureScheme, priv crypto.Signer) (*x509.Certificate, error) {
	fmt.Println("🧪 newSelfSigned wurde aufgerufen")
	/*sigAlg, ok := x509AlgMap[alg]
	  if !ok {
	      return nil, fmt.Errorf("tls.selfsigned: Unknown signature algorithm [%04x]", alg)
	  }*/
	if len(name) == 0 {
		return nil, fmt.Errorf("tls.selfsigned: No name provided")
	}

	/*serial, err := rand.Int(rand.Reader, big.NewInt(0xA0A0A0A0))
	  if err != nil {
	      return nil, err
	  }*/

	template := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject: pkix.Name{
			CommonName: "localhost",
		},
		DNSNames:              []string{"localhost"},
		NotBefore:             time.Now(),
		NotAfter:              time.Now().AddDate(0, 0, 1),
		SignatureAlgorithm:    x509.SHA256WithRSA,
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}

	der, err := x509.CreateCertificate(rand.Reader, template, template, priv.Public(), priv)
	if err != nil {
		return nil, err
	}

	// It is safe to ignore the error here because we're parsing known-good data
	cert, err := x509.ParseCertificate(der)
	if err != nil {
		fmt.Printf("Fehler beim Parsen des Zertifikats: %v", err)
		return nil, err
	}

	fmt.Printf("📛 DNSNames im geparsten Zertifikat: %v", cert.DNSNames)
	return cert, nil

}

func main() {

	// 1. Generiere Schlüsselpaar
	priv, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		log.Fatal("Fehler beim Erzeugen des privaten Schlüssels:", err)
	}

	// 2. Erstelle Self-Signed-Zertifikat
	cert, err := newSelfSigned("localhost", mint.RSA_PKCS1_SHA256, priv) // Aufruf der Funktion
	if err != nil {
		log.Fatal("Fehler beim Erstellen des Zertifikats:", err)
	}
	pskCache := mint.NewInMemoryPSKCache()
	// 3. Baue Mint-Konfiguration
	conf := &mint.Config{
		ServerName: "localhost",

		Certificates: []*mint.Certificate{
			{
				Chain:      []*x509.Certificate{cert},
				PrivateKey: priv,
			},
		},

		SupportedVersions: []mint.TLSVersion{mint.TLS13},
		CipherSuites:      mint.DefaultCipherSuites(),

		RequireClientAuth:   false,
		RequireCookie:       false,
		AllowInsecureHashes: true,
		Enable0RTT:          true, // erstmal sicher deaktivieren
		SendSessionTickets:  true, // aktiviert die automatische Erzeugung und das Verschicken von NewSessionTicket-Nachrichten
		AllowEarlyData:      true,
		TicketLen:           32, // Länge des Session-tickets muss > 0 sein, das bestimmt wieviele zufallsbytes für das ticket
		// also quasi die nonce, erstellt werden
		EarlyDataLifetime: 10 * 60, // 10 Minuten gültig
		TicketLifetime:    10 * 60, // 10 Minuten gültig
		PSKModes:          []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
		PSKs:              pskCache,

		SignatureSchemes: []mint.SignatureScheme{
			mint.RSA_PKCS1_SHA256, //  Muss zum Cert passen
		},
		Groups: []mint.NamedGroup{
			mint.X25519,
		},
		NextProtos: []string{"h2"},
	}

	// 4. Starte TCP-Listener
	ln, err := net.Listen("tcp", ":4444")
	if err != nil {
		log.Fatal(err)
	}
	log.Println("Server wartet auf Verbindungen...")

	for {
		rawConn, err := ln.Accept()
		if err != nil {
			log.Fatal(err)
		}
		go func() {
			conn := mint.Server(rawConn, conf)

			// SOFORT Handshake!
			alert := conn.Handshake()
			if alert != mint.AlertNoAlert {
				log.Printf("Handshake fehlgeschlagen: 0x%x\n", alert)
				return
			}
			log.Println("Handshake erfolgreich")
			go handleEcho(conn)

			// 2. REPLAY-RESISTENZ-PRÜFUNG – direkt nach dem Handshake!
			if conn.UsingEarlyData && conn.UsedPSKIdentity != nil {
				if usedPSKs.Test(conn.UsedPSKIdentity) {
					log.Println("⚠️ Replay erkannt! Verbindung wird abgebrochen.")
					conn.Close()
					return
				}
				usedPSKs.Add(conn.UsedPSKIdentity)
				log.Printf(" PSK %x als benutzt markiert (Replay-Resistenz)", conn.UsedPSKIdentity)

				log.Printf("🔍 Server: UsingEarlyData = %v", conn.UsingEarlyData)

				// OPTIONAL: Puncturing
				if cache, ok := conf.PSKs.(*mint.InMemoryPSKCache); ok {
					key := fmt.Sprintf("%x", conn.UsedPSKIdentity)
					delete(cache.Session, key)
					log.Printf("PSK %s aus Cache gelöscht (Puncturing)", key)
				}
			}

			// EarlyData-Prüfung
			if conn.UsingEarlyData {
				log.Println("SERVER: UsingEarlyData = TRUE – Jetzt EarlyData lesen ...")
				buf := make([]byte, 1024)
				n, err := conn.Read(buf)
				if n > 0 {
					log.Printf("🌟 Early Data empfangen: %s", string(buf[:n]))
				} else {
					log.Printf("Kein Early Data empfangen, err=%v", err)
				}

			}
			if conn.UsingEarlyData {
				log.Println("🚀 SERVER: UsingEarlyData = TRUE – Jetzt EarlyData lesen ...")
				buf := make([]byte, 1024)
				n, err := conn.Read(buf)
				if err == nil && n > 0 {
					log.Printf("🌟 Early Data empfangen: %s", string(buf[:n]))
					// Echo zurück!
					conn.Write(buf[:n])
				}
			}

			log.Printf("[DEBUG] Nach Handshake: UsingEarlyData=%v, UsedPSKIdentity=%x", conn.UsingEarlyData, conn.UsedPSKIdentity)

			// Normale Nachrichten nach Handshake: Echo-Schleife!
			for {
				buf := make([]byte, 1024)
				n, err := conn.Read(buf)
				if err != nil {
					log.Println("Fehler beim Lesen:", err)
					break // Verbindung schließen
				}
				log.Println("Nachricht empfangen nach Handshake:", string(buf[:n]))
				// Echo zurück an Client:
				_, err = conn.Write(buf[:n])
				if err != nil {
					log.Println("Fehler beim Antworten:", err)
					break
				}
			}
			conn.Close()

			// Normale Nachrichten nach Handshake
			buf := make([]byte, 1024)
			n, err := conn.Read(buf)
			if err != nil {
				log.Println("Fehler beim Lesen:", err)
				return
			}
			log.Println("Nachricht empfangen nach Handshake:", string(buf[:n]))

			conn.Close()
		}()
	}
}
