package main

import (
	"encoding/csv"
	"encoding/gob"
	"fmt"
	"log"
	"net"
	"os"
	"reflect"
	"runtime"
	"strconv"
	"time"

	"github.com/michellejns/mint"
)

type SendEarlyData struct {
	Data []byte
}

type FileBackedCache struct {
	*mint.InMemoryPSKCache
	filename string
}

func printMemUsageCSV(run int, mode string, filename string) {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	memMB := float64(m.HeapAlloc) / 1024.0 / 1024.0
	f, err := os.OpenFile(filename, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Printf("Fehler beim Schreiben der Speicherdatei: %v", err)
		return
	}
	defer f.Close()
	if run == 1 {
		// Schreibe Header
		f.WriteString("Run;Mode;Memory_MB\n")
	}
	line := fmt.Sprintf("%d;%s;%.6f\n", run, mode, memMB)
	f.WriteString(line)
}

func NewFileBackedCache(filename string) *FileBackedCache {
	return &FileBackedCache{
		InMemoryPSKCache: mint.NewInMemoryPSKCache(),
		filename:         filename,
	}
}

func (f *FileBackedCache) Put(_ string, psk mint.PreSharedKey) {
	key := fmt.Sprintf("%x", psk.Identity)
	log.Printf("📝 [FileBackedCache.Put] Speichere Identity '%x' (gültig bis %v)", key, psk.ExpiresAt)
	psk.AllowEarlyData = true
	psk.EarlyDataLifetime = 600

	// Immer nur einen PSK behalten!
	for k := range f.Session {
		if k != key {
			delete(f.Session, k)
		}
	}

	f.InMemoryPSKCache.Put(key, psk)
	f.save()
}

func (f *FileBackedCache) save() {
	log.Printf("[FileBackedCache.save] Versuche zu speichern: %s", f.filename)
	file, err := os.Create(f.filename)
	if err != nil {
		log.Println("Fehler beim Speichern des PSK-Caches:", err)
		return
	}
	defer file.Close()

	encoder := gob.NewEncoder(file)
	err = encoder.Encode(f.Session)
	if err != nil {
		log.Println("Fehler beim Serialisieren des PSK-Caches:", err)
	} else {
		log.Println(" PSK-Cache gespeichert.")
	}
}

func (f *FileBackedCache) Get(identity string) (mint.PreSharedKey, bool) {
	// 1. Versuche direkten Lookup (Hex-Keys)
	if psk, ok := f.Session[identity]; ok {
		return psk, true
	}
	// 2. Falls identity nicht schon hex ist: versuche es als Hex
	key := fmt.Sprintf("%x", []byte(identity))
	if psk, ok := f.Session[key]; ok {
		return psk, true
	}
	// 3. Workaround: Nur ein Key im Cache, aber gesucht wird "localhost"
	if identity == "localhost" && len(f.Session) == 1 {
		for _, psk := range f.Session {
			log.Println("⚠️ Workaround: Liefere einzigen PSK für 'localhost'")
			return psk, true
		}
	}
	return mint.PreSharedKey{}, false
}

func LoadFileBackedCache(filename string) *FileBackedCache {
	f := NewFileBackedCache(filename)
	file, err := os.Open(filename)
	if err != nil {
		log.Println("Kein gespeicherter PSK gefunden.")
		return f
	}
	defer file.Close()

	decoder := gob.NewDecoder(file)
	err = decoder.Decode(&f.Session)
	if err != nil {
		log.Println("Fehler beim Laden des PSK-Caches:", err)
	} else {
		log.Println("PSK-Cache geladen.")
	}
	return f
}
func freshConfig() *mint.Config {
	return &mint.Config{
		ServerName:         "localhost",
		PSKs:               LoadFileBackedCache("psk_cache.gob"),
		AllowEarlyData:     true,
		InsecureSkipVerify: true,
		SupportedVersions:  []mint.TLSVersion{mint.TLS13},
		CipherSuites:       mint.DefaultCipherSuites(),
		Enable0RTT:         true,
		EarlyDataLifetime:  600,
		PSKModes:           []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
		SignatureSchemes:   []mint.SignatureScheme{mint.RSA_PKCS1_SHA256},
		Groups:             []mint.NamedGroup{mint.X25519},
		NextProtos:         []string{"h2"},
	}
}

/*func runBenchmarks(pskFile string, serverAddr string, numRuns int) {
	file, err := os.Create("benchmark_results.csv")
	if err != nil {
		log.Fatalf("Fehler beim Erstellen der CSV: %v", err)
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()
	writer.Write([]string{"Run", "HandshakeDuration_ms", "Used0RTT"})
	results := [][]string{}

	cache := LoadFileBackedCache(pskFile)

	for i := 1; i <= numRuns; i++ {
		log.Printf("== Benchmark Run %d ==", i)
		log.Printf("[DEBUG] PSK-Cache Size: %d", cache.Size())
		rawConn, err := net.Dial("tcp", serverAddr)
		if err != nil {
			log.Fatal(err)
		}
		conf := freshConfig()
		c2 := mint.Client(rawConn, conf)

		early := []byte("Hallo vom Client via 0-RTT!")
		c2.EarlyData = early
		log.Printf("[DEBUG] EarlyData im Client gesetzt: %q", string(c2.EarlyData))

		startHandshake := time.Now()
		_ = c2.Handshake()
		handshakeDuration := time.Since(startHandshake).Milliseconds()

		//used0RTT := strconv.FormatBool(c2.UsingEarlyData)
		results = append(results, []string{
			strconv.Itoa(i),
			strconv.FormatInt(handshakeDuration, 10),
			//used0RTT,
		})

		c2.Close()
	}
	for _, row := range results {
		writer.Write(row)
	}
	log.Println("Benchmark abgeschlossen. Ergebnisse in benchmark_results.csv")
}*/

func doInitialHandshake(pskFile string, conf *mint.Config, serverAddr string) {
	log.Println("=== 1. Normale Verbindung zum Sammeln des PSK ===")
	rawConn, err := net.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatal(err)
	}
	c := mint.Client(rawConn, conf)
	if alert := c.Handshake(); alert != mint.AlertNoAlert {
		log.Fatalf("Handshake fehlgeschlagen: %x", alert)
	}
	log.Println(" Handshake abgeschlossen, warte auf SessionTicket...")

	// Nach Handshake versuchen wir ein paar mal zu lesen, damit das SessionTicket verarbeitet wird
	for i := 0; i < 10; i++ {
		buf := make([]byte, 2048)
		n, err := c.Read(buf)
		log.Printf("[Post-Handshake-Read %d] n=%d, err=%v", i, n, err)
		time.Sleep(100 * time.Millisecond)
	}
	c.Close()
	log.Println("=== Fertig! Jetzt kann 0-RTT getestet werden. ===")
}

/*func doZeroRTT(pskFile string, conf *mint.Config, serverAddr string) {
	log.Println("=== 2. 0-RTT Verbindung ===")
	cache := LoadFileBackedCache(pskFile)
	log.Printf("[DEBUG] PSK-Cache Size: %d", cache.Size())
	log.Printf("[DEBUG] Session-Keys: %v", reflect.ValueOf(cache.InMemoryPSKCache.Session).MapKeys())

	rawConn, err := net.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatal(err)
	}
	c2 := mint.Client(rawConn, conf)

	// 0-RTT Daten setzen
	early := []byte("Hallo vom Client via 0-RTT!")

	go func() {
		time.Sleep(50 * time.Millisecond)
		c2.Write([]byte("0-RTT Test EarlyData!"))
	}()
	if alert := c2.Handshake(); alert != mint.AlertNoAlert {
		log.Fatalf("Handshake fehlgeschlagen: %x", alert)
	}


	c2.EarlyData = early
	log.Printf("Setze Early Data: %q", string(early))
	log.Println("Alle PSKs im Cache:")
	for k, psk := range cache.InMemoryPSKCache.Session {
		log.Printf("Key: %s, AllowEarlyData: %v, ExpiresAt: %v, Identity: %x", k, psk.AllowEarlyData, psk.ExpiresAt, psk.Identity)
	}

	if alert := c2.Handshake(); alert != mint.AlertNoAlert {
		log.Fatalf("Handshake fehlgeschlagen: %x", alert)
	}
	log.Println("Handshake abgeschlossen (mit/ohne 0-RTT)")

	log.Printf("UsingEarlyData: %v", c2.UsingEarlyData)

	if c2.UsingEarlyData {
		log.Println("0-RTT wurde genutzt!")
	} else {
		log.Println("0-RTT wurde NICHT genutzt!")
	}

	_, err = c2.Write([]byte("hello after 0-RTT connect"))
	if err != nil {
		log.Printf("Fehler beim Schreiben nach 0-RTT-Handshake: %v", err)
	}
	buf := make([]byte, 1024)
	n, err := c2.Read(buf)
	if err != nil {
		log.Printf("Fehler beim Lesen nach Handshake: %v", err)
	} else {
		log.Println("Antwort vom Server:", string(buf[:n]))
	}

	c2.Close()
}*/

// !!!funktionierende doZeroRTT-Funktion!!!
func doZeroRTT(pskFile string, conf *mint.Config, serverAddr string) {
	log.Println("=== 2. 0-RTT Verbindung ===")
	cache := LoadFileBackedCache(pskFile)
	log.Printf("[DEBUG] PSK-Cache Size: %d", cache.Size())
	log.Printf("[DEBUG] Session-Keys: %v", reflect.ValueOf(cache.InMemoryPSKCache.Session).MapKeys())

	rawConn, err := net.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatal(err)
	}
	c2 := mint.Client(rawConn, conf)

	// Hier: 0-RTT EarlyData vor dem Handshake setzen!
	early := []byte(" Hallo vom Client via 0-RTT!")
	c2.EarlyData = early
	log.Printf("[DEBUG] EarlyData im Client gesetzt: %q", string(c2.EarlyData))

	log.Println("Alle PSKs im Cache:")
	for k, psk := range cache.InMemoryPSKCache.Session {
		log.Printf("Key: %s, AllowEarlyData: %v, ExpiresAt: %v, Identity: %x", k, psk.AllowEarlyData, psk.ExpiresAt, psk.Identity)
	}

	// *** Handshake-Zeit MESSEN ***
	startHandshake := time.Now()
	if alert := c2.Handshake(); alert != mint.AlertNoAlert {
		log.Fatalf("Handshake fehlgeschlagen: %x", alert)
	}
	handshakeDuration := time.Since(startHandshake)
	log.Printf("Handshake dauerte: %v", handshakeDuration)

	log.Println("Handshake abgeschlossen (mit/ohne 0-RTT)")
	log.Printf("UsingEarlyData: %v", c2.UsingEarlyData)

	if c2.UsingEarlyData {
		log.Println("0-RTT wurde genutzt!")
	} else {
		log.Println("0-RTT wurde NICHT genutzt!")
	}

	// *** Write-Zeit messen (optional, z. B. nach Handshake) ***
	startWrite := time.Now()
	_, err = c2.Write([]byte("hello after 0-RTT connect"))
	writeDuration := time.Since(startWrite)
	if err != nil {
		log.Printf("Fehler beim Schreiben nach 0-RTT-Handshake: %v", err)
	} else {
		log.Printf(" Write nach Handshake dauerte: %v", writeDuration)
	}

	buf := make([]byte, 1024)
	n, err := c2.Read(buf)
	if err != nil {
		log.Printf("Fehler beim Lesen nach Handshake: %v", err)
	} else {
		log.Println("Antwort vom Server:", string(buf[:n]))
	}

	c2.Close()
}

func doZeroRTTBench(pskFile string, conf *mint.Config, serverAddr string, runs int) {
	os.Remove("memory_benchmark_0rtt.csv")
	log.Println("=== 0-RTT Benchmark-Loop ===")
	file, err := os.Create("benchmark_results.csv")
	if err != nil {
		log.Fatalf("Fehler beim Erstellen der CSV: %v", err)
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	writer.Write([]string{"Run", "HandshakeDuration_ms", "Used0RTT"})

	for i := 1; i <= runs; i++ {

		log.Printf("== 0-RTT Run %d ==", i)
		cache := LoadFileBackedCache(pskFile)
		log.Printf("[DEBUG] PSK-Cache Size: %d", cache.Size())
		log.Printf("[DEBUG] Session-Keys: %v", reflect.ValueOf(cache.InMemoryPSKCache.Session).MapKeys())

		rawConn, err := net.Dial("tcp", serverAddr)
		if err != nil {
			log.Fatal(err)
		}
		c2 := mint.Client(rawConn, conf)

		// EarlyData setzen
		early := []byte(" Hallo vom Client via 0-RTT!")
		c2.EarlyData = early
		log.Printf("[DEBUG] EarlyData im Client gesetzt: %q", string(c2.EarlyData))

		// Debug-Ausgabe der PSKs im Cache
		pskCache, ok := conf.PSKs.(*FileBackedCache)
		if !ok {
			log.Println("conf.PSKs ist kein FileBackedCache!")
		} else {
			log.Println("Alle PSKs im FileBackedCache:")
			for k, v := range pskCache.Session {
				log.Printf("Key: %s\n  AllowEarlyData: %v\n  ExpiresAt: %v\n  Identity: %x\n",
					k, v.AllowEarlyData, v.ExpiresAt, v.Identity)
			}
		}

		startHandshake := time.Now()
		alert := c2.Handshake()
		handshakeDuration := float64(time.Since(startHandshake).Nanoseconds()) / 1e6
		durationStr := fmt.Sprintf("%.6f", handshakeDuration)
		used0RTT := strconv.FormatBool(c2.ConnectionState().UsingEarlyData)

		if alert != mint.AlertNoAlert {
			log.Printf("Handshake fehlgeschlagen: %x", alert)
		}
		if c2.UsingEarlyData {
			log.Println("0-RTT wurde genutzt!")
		} else {
			log.Println("0-RTT wurde NICHT genutzt!")
		}

		writer.Write([]string{
			strconv.Itoa(i),
			durationStr,
			used0RTT,
		})

		printMemUsageCSV(i, "0-RTT", "memory_benchmark_0rtt.csv")

		c2.Close()
		//time.Sleep(100 * time.Millisecond) // Kurze Pause zwischen den Runs
		log.Printf("Run %d abgeschlossen.\n", i)

	}
	log.Println("Benchmark abgeschlossen. Ergebnisse in benchmark_results.csv")
}

// doFullHandshakeBench führt eine Reihe von vollständigen Handshakes durch und misst die Dauer jedes Handshakes.
// ohne PSK und ohne 0-RTT.
func doFullHandshakeBench(serverAddr string, runs int) {
	os.Remove("memory_benchmark_full.csv")
	log.Println("=== Full Handshake Benchmark-Loop ===")
	file, err := os.Create("fullhandshake_benchmark.csv")
	if err != nil {
		log.Fatalf("Fehler beim Erstellen der CSV: %v", err)
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	writer.Write([]string{"Run", "HandshakeDuration_ms", "Used0RTT"})

	for i := 1; i <= runs; i++ {
		log.Printf("== Full Handshake Run %d ==", i)
		conf := &mint.Config{
			ServerName:         "localhost",
			InsecureSkipVerify: true,
			SupportedVersions:  []mint.TLSVersion{mint.TLS13},
			CipherSuites:       mint.DefaultCipherSuites(),
			Enable0RTT:         false,
			AllowEarlyData:     false,
			EarlyDataLifetime:  0,
			PSKs:               nil,
			PSKModes:           []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
			SignatureSchemes:   []mint.SignatureScheme{mint.RSA_PKCS1_SHA256},
			Groups:             []mint.NamedGroup{mint.X25519},
			NextProtos:         []string{"h2"},
		}

		rawConn, err := net.Dial("tcp", serverAddr)
		if err != nil {
			log.Fatal(err)
		}
		c := mint.Client(rawConn, conf)

		startHandshake := time.Now()
		alert := c.Handshake()
		handshakeDuration := float64(time.Since(startHandshake).Microseconds()) / 1000.0 // ms mit Kommastellen
		used0RTT := strconv.FormatBool(c.ConnectionState().UsingEarlyData)

		if alert != mint.AlertNoAlert {
			log.Printf("Handshake fehlgeschlagen: %x", alert)
		} else {
			log.Printf("Full Handshake abgeschlossen")
		}

		writer.Write([]string{
			strconv.Itoa(i),
			fmt.Sprintf("%.6f", handshakeDuration),
			used0RTT,
		})
		// Nach jedem Run:
		printMemUsageCSV(i, "Full", "memory_benchmark_full.csv")

		c.Close()
	}
	log.Println("Full Handshake Benchmark abgeschlossen. Ergebnisse in fullhandshake_benchmark.csv")
}

func latencyBenchmarkSingleConnection(pskFile string, conf *mint.Config, serverAddr string, runs int, outfile string) {
	file, _ := os.Create(outfile)
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	writer.Write([]string{"Run", "RTT_ms"})

	rawConn, err := net.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatalf("Fehler beim Verbinden: %v", err)
	}
	c := mint.Client(rawConn, conf)
	if alert := c.Handshake(); alert != mint.AlertNoAlert {
		log.Fatalf("TLS Handshake fehlgeschlagen: %x", alert)
	}
	log.Printf("Handshake erfolgreich, starte RTT-Loop...")

	payload := []byte("ping")
	buf := make([]byte, 1024)

	for i := 1; i <= runs; i++ {
		start := time.Now()
		_, err := c.Write(payload)
		if err != nil {
			log.Printf("Write error: %v", err)
			continue
		}
		n, err := c.Read(buf)
		if err != nil {
			log.Printf("Read error: %v", err)
			continue
		}
		elapsed := float64(time.Since(start).Microseconds()) / 1000.0
		writer.Write([]string{strconv.Itoa(i), fmt.Sprintf("%.4f", elapsed)})

		if string(buf[:n]) != "ping" {
			log.Printf("Echo mismatch! %q", buf[:n])
		}
	}
	writer.Flush()
	c.Close()
	log.Println("RTT-Benchmark abgeschlossen. Ergebnisse in", outfile)
}

func doZeroRTTLatencyBench(pskFile string, conf *mint.Config, serverAddr string, runs int, outfile string) {
	// 1. Initialer 1-RTT-Handshake für SessionTicket
	//doInitialHandshake(pskFile, conf, serverAddr)

	// 2. Konfig für 0-RTT aktivieren
	conf.AllowEarlyData = true
	conf.Enable0RTT = true

	file, _ := os.Create("latency_0rtt.csv")
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	writer.Write([]string{"Run", "RTT_ms"})

	for i := 1; i <= runs; i++ {
		cache := LoadFileBackedCache(pskFile)
		conf.PSKs = cache

		rawConn, err := net.Dial("tcp", serverAddr)
		if err != nil {
			log.Fatal(err)
		}
		c := mint.Client(rawConn, conf)
		c.EarlyData = []byte("ping") // Wird als 0-RTT Data gesendet

		start := time.Now()
		alert := c.Handshake()
		if alert != mint.AlertNoAlert {
			log.Printf("Run %d: TLS Handshake fehlgeschlagen: %x", i, alert)
			rawConn.Close()
			continue
		}

		elapsed := float64(time.Since(start).Microseconds()) / 1000.0 // Handshake+Ping
		writer.Write([]string{strconv.Itoa(i), fmt.Sprintf("%.4f", elapsed)})

		// (Optional) Lies Serverantwort und prüfe sie
		buf := make([]byte, 1024)
		n, _ := c.Read(buf)
		if n > 0 {
			log.Printf("Run %d: Antwort vom Server: %s", i, string(buf[:n]))
		}
		c.Close()
	}
	log.Println("0-RTT Latenz-Benchmark abgeschlossen.")
}

func main() {
	const serverAddr = "localhost:4444"

	const pskFile = "psk_cache.gob"

	//mode := flag.String("mode", "0rtt", "Handshake-Modus: full, 1rtt, 0rtt")
	//runs := flag.Int("runs", 1, "Wie oft soll getestet werden?")
	//serverAddr := flag.String("server", "localhost:4444", "Server-Adresse")
	//flag.Parse()

	//mode := flag.String("mode", "0rtt", "Handshake-Modus: full, 1rtt, 0rtt, latency")
	//runs := flag.Int("runs", 100, "Wie oft soll getestet werden?")
	//serverAddr := flag.String("server", "localhost:4444", "Server-Adresse")
	//flag.Parse()

	// ----- Gemeinsame Mint-Konfig -----
	cache := LoadFileBackedCache(pskFile)
	conf := &mint.Config{
		ServerName:         "localhost",
		InsecureSkipVerify: true,
		SupportedVersions:  []mint.TLSVersion{mint.TLS13},
		CipherSuites:       mint.DefaultCipherSuites(),
		Enable0RTT:         true,
		AllowEarlyData:     true,
		EarlyDataLifetime:  600,
		PSKs:               cache,
		PSKModes:           []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
		SignatureSchemes:   []mint.SignatureScheme{mint.RSA_PKCS1_SHA256},
		Groups:             []mint.NamedGroup{mint.X25519},
		NextProtos:         []string{"h2"},
	}

	/*	switch *mode {

		case "latency":
			// Verbindung aufbauen (wie beim Handshake)
			rawConn, err := net.Dial("tcp", *serverAddr)
			if err != nil {
				log.Fatal(err)
			}
			defer rawConn.Close()

			// Handshake durchführen (optional/empfohlen!)
			c := mint.Client(rawConn, conf)
			if alert := c.Handshake(); alert != mint.AlertNoAlert {
				log.Fatalf("Handshake fehlgeschlagen: %x", alert)
			}
			log.Println("Handshake abgeschlossen, starte Latenz-Benchmark...")

			// Jetzt den eigentlichen Latenz-Benchmark aufrufen:
			latencyBenchmark(rawConn, *runs, "latency_benchmark.csv")

		case "full":

			// Für jeden Lauf PSK-Datei löschen, damit kein Resumption möglich ist:
			os.Remove(pskFile)
			doFullHandshakeBench(*serverAddr, *runs)

		case "1rtt":
			// Erst Initial-Handshake machen (zum PSK erzeugen), dann doZeroRTTBench mit EarlyData deaktiviert
			doInitialHandshake(pskFile, conf, *serverAddr)
			conf.AllowEarlyData = false
			conf.Enable0RTT = false
			doZeroRTTBench(pskFile, conf, *serverAddr, *runs)
		case "0rtt":
			// Erst Initial-Handshake, dann Bench mit 0-RTT aktiviert
			doInitialHandshake(pskFile, conf, *serverAddr)
			conf.AllowEarlyData = true
			conf.Enable0RTT = true
			doZeroRTTBench(pskFile, conf, *serverAddr, *runs)
		}*/
	// ------ Ablauf wählen ------
	//Test für handshake ohne psk und ohne 0-rtt
	//doFullHandshakeBench("localhost:4444", 100)

	if cache.Size() == 0 {
		doInitialHandshake(pskFile, conf, serverAddr)
		//latencyBenchmarkSingleConnection(pskFile, conf, serverAddr, 100, "latency_benchmark.csv")
		//doFullHandshakeBench(serverAddr, 100)
	} else {
		doZeroRTT(pskFile, conf, serverAddr)
		//Test für 0-RTT mit PSK
		//doZeroRTTBench(pskFile, conf, serverAddr, 100)

		//latencyBenchmarkSingleConnection(pskFile, conf, serverAddr, 100, "latency_benchmark.csv")
		//doZeroRTTLatencyBench(pskFile, conf, serverAddr, 100, "latency_0rtt.csv")
		//doInitialHandshake("psk_cache.gob", conf, "localhost:4444")
		//doZeroRTTBench(pskFile, conf, serverAddr, 10)

	}

}
