package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"crypto/x509/pkix"
	"log"
	"math/big"
	"net"
	"time"

	"github.com/michellejns/mint"
)

func newSelfSigned() (*x509.Certificate, *rsa.PrivateKey) {
	priv, _ := rsa.GenerateKey(rand.Reader, 2048)
	tmpl := &x509.Certificate{
		SerialNumber:       big.NewInt(1),
		Subject:            pkix.Name{CommonName: "localhost"},
		DNSNames:           []string{"localhost"},
		NotBefore:          time.Now(),
		NotAfter:           time.Now().AddDate(0, 0, 1),
		KeyUsage:           x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
		ExtKeyUsage:        []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		SignatureAlgorithm: x509.SHA256WithRSA,
	}
	der, _ := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &priv.PublicKey, priv)
	cert, _ := x509.ParseCertificate(der)
	return cert, priv
}

func main() {
	cert, priv := newSelfSigned()

	conf := &mint.Config{
		ServerName: "localhost",
		Certificates: []*mint.Certificate{{
			Chain:      []*x509.Certificate{cert},
			PrivateKey: priv,
		}},
		SupportedVersions:  []mint.TLSVersion{mint.TLS13},
		CipherSuites:       mint.DefaultCipherSuites(),
		Enable0RTT:         true,
		AllowEarlyData:     true,
		EarlyDataLifetime:  600,
		TicketLifetime:     600,
		SendSessionTickets: true,
		PSKs:               mint.NewInMemoryPSKCache(),
		PSKModes:           []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
		SignatureSchemes:   []mint.SignatureScheme{mint.RSA_PKCS1_SHA256},
		Groups:             []mint.NamedGroup{mint.X25519},
		NextProtos:         []string{"h2"},
	}

	ln, err := net.Listen("tcp", ":4444")
	if err != nil {
		log.Fatal(err)
	}
	log.Println("Mint-DEMO-Server lauscht auf :4444")

	for {
		rawConn, _ := ln.Accept()
		go func() {
			conn := mint.Server(rawConn, conf)
			alert := conn.Handshake()
			if alert != mint.AlertNoAlert {
				log.Printf("❌ Handshake fehlgeschlagen: 0x%x\n", alert)
				return
			}
			log.Println("✅ Handshake erfolgreich (Server)")

			if conn.UsingEarlyData {
				buf := make([]byte, 1024)
				n, _ := conn.Read(buf)
				log.Printf("🌟 SERVER: EarlyData empfangen: %s", string(buf[:n]))
			} else {
				log.Println("🚀 SERVER: Keine EarlyData empfangen (UsingEarlyData = false)")
			}

			// Empfange normale Nachricht (nach Handshake)
			buf := make([]byte, 1024)
			n, err := conn.Read(buf)
			if err == nil {
				log.Printf("Nach Handshake empfangen: %s", string(buf[:n]))
			}
			conn.Close()
		}()
	}
}
