/*package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"math"
	"os"
	"strconv"
)

func main() {
	file, err := os.Open("benchmark_full.csv")
	fmt.Printf("enchmark_full.csv")

	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	reader := csv.NewReader(file)
	reader.Comma = ';'
	records, err := reader.ReadAll()
	if err != nil {
		log.Fatal(err)
	}

	var rtt0, rtt1 []float64

	for i, rec := range records {
		if i == 0 {
			continue // Header
		}
		if len(rec) < 3 {
			continue
		}
		typ := rec[1]
		val, err := strconv.ParseFloat(rec[2], 64)
		if err != nil {
			continue
		}
		if typ == "0-RTT" {
			rtt0 = append(rtt0, val)
		} else if typ == "1-RTT" {
			rtt1 = append(rtt1, val)
		}
	}

	printStats := func(label string, values []float64) {
		if len(values) == 0 {
			fmt.Println(label + ": keine Werte vorhanden.")
			return
		}
		sum := 0.0
		min := math.MaxFloat64
		max := -math.MaxFloat64
		for _, v := range values {
			sum += v
			if v < min {
				min = v
			}
			if v > max {
				max = v
			}
		}
		mean := sum / float64(len(values))
		std := 0.0
		for _, v := range values {
			std += (v - mean) * (v - mean)
		}
		std = math.Sqrt(std / float64(len(values)))

		fmt.Printf("%s:\n", label)
		fmt.Printf("  Mittelwert      : %.6f s\n", mean)
		fmt.Printf("  Standardabw.    : %.6f s\n", std)
		fmt.Printf("  Minimum         : %.6f s\n", min)
		fmt.Printf("  Maximum         : %.6f s\n\n", max)
	}

	printStats("0-RTT", rtt0)
	printStats("1-RTT", rtt1)
}
*/