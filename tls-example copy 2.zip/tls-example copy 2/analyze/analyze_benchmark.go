package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"math"
	"os"
	"strconv"
)

func main() {

	files := []struct {
		Filename string
		Label    string
	}{

		//{"latency_benchmark.csv", "handshake"},
		//{"latency_0rtt.csv", "0-rtt Handshake (ohne Replay-Resistenz und Puncturing)"},
		{"crypto_benchmark.csv", "ECDH + HKDF"},
	}

	for _, file := range files {
		fmt.Printf("\n---- Auswertung für: %s ----\n", file.Label)
		analyzeCSV(file.Filename)
	}
}

func analyzeCSV(filename string) {
	f, err := os.Open(filename)
	if err != nil {
		log.Fatalf("Kann Datei %s nicht öffnen: %v", filename, err)
	}
	defer f.Close()

	r := csv.NewReader(f)
	records, err := r.ReadAll()
	if err != nil {
		log.Fatalf("Fehler beim Lesen: %v", err)
	}

	if len(records) < 2 {
		log.Println("Nicht genug Daten.")
		return
	}

	maxRuns := 100
	numRows := len(records) - 1 // abzüglich Header
	if numRows < maxRuns {
		maxRuns = numRows
	}

	var times []float64
	for i := 0; i < maxRuns; i++ {
		row := records[i+1] // +1 wegen Header
		val, err := strconv.ParseFloat(row[1], 64)
		if err != nil {
			log.Printf("Zeile %d konnte nicht gelesen werden: %v", i+2, err)
			continue
		}
		times = append(times, val)
	}

	n := float64(len(times))
	if n == 0 {
		fmt.Println("Keine Werte!")
		return
	}
	sum := 0.0
	min, max := times[0], times[0]
	for _, t := range times {
		sum += t
		if t < min {
			min = t
		}
		if t > max {
			max = t
		}
	}
	mean := sum / n
	stddev := 0.0
	for _, t := range times {
		stddev += (t - mean) * (t - mean)
	}
	stddev = math.Sqrt(stddev / n)

	fmt.Printf("Runs (max 100): %d\n", int(n))
	fmt.Printf("Min:    %.6f ms\n", min)
	fmt.Printf("Max:    %.6f ms\n", max)
	fmt.Printf("Mean:   %.6f ms\n", mean)
	fmt.Printf("StdDev: %.6f ms\n", stddev)
}
