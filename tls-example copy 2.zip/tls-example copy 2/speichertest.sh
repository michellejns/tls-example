#!/bin/bash

RUNS=30

# 1. Full Handshake
OUTFILE_FULL="mem_full.csv"
echo "Durchlauf;Typ;Memory_MB" > "$OUTFILE_FULL"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (Full Handshake) ========"
    MEM=$(go run client/client.go --mode=full 2>&1 | grep MEM_MB= | tail -n1 | sed 's/MEM_MB=//')
    echo "$i;Full;$MEM" >> "$OUTFILE_FULL"
done

# 2. 1-RTT Handshake
OUTFILE_1RTT="mem_1rtt.csv"
echo "Durchlauf;Typ;Memory_MB" > "$OUTFILE_1RTT"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (1-RTT) ========"
    MEM=$(go run client/client.go --mode=1rtt 2>&1 | grep MEM_MB= | tail -n1 | sed 's/MEM_MB=//')
    echo "$i;1-RTT;$MEM" >> "$OUTFILE_1RTT"
done

# 3. 0-RTT ohne Replay/Puncturing
OUTFILE_0RTT_NO_REPLAY="mem_0rtt_no_replay.csv"
echo "Durchlauf;Typ;Memory_MB" > "$OUTFILE_0RTT_NO_REPLAY"
echo ">> Server OHNE Replay-Detection/Puncturing laufen lassen!"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (0-RTT ohne Replay/Puncturing) ========"
    MEM=$(go run client/client.go --mode=0rtt 2>&1 | grep MEM_MB= | tail -n1 | sed 's/MEM_MB=//')
    echo "$i;0-RTT_noReplayNoPuncture;$MEM" >> "$OUTFILE_0RTT_NO_REPLAY"
done

# 4. 0-RTT mit Replay-Detection & Puncturing
OUTFILE_0RTT_REPLAY="mem_0rtt_replay.csv"
echo "Durchlauf;Typ;Memory_MB" > "$OUTFILE_0RTT_REPLAY"
echo ">> Server MIT Replay-Detection & Puncturing laufen lassen!"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (0-RTT mit Replay/Puncturing) ========"
    MEM=$(go run client/client.go --mode=0rtt 2>&1 | grep MEM_MB= | tail -n1 | sed 's/MEM_MB=//')
    echo "$i;0-RTT_ReplayPuncture;$MEM" >> "$OUTFILE_0RTT_REPLAY"
done

echo "Alle Speicherbenchmarks abgeschlossen."
echo "  $OUTFILE_FULL"
echo "  $OUTFILE_1RTT"
echo "  $OUTFILE_0RTT_NO_REPLAY"
echo "  $OUTFILE_0RTT_REPLAY"
