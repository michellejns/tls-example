package main

import (
	"log"
	"net"
	"time"

	"github.com/michellejns/mint"
)

func main() {
	// 1. Initialisiere InMemory-PSK-Cache und Mint-Config
	cache := mint.NewInMemoryPSKCache()
	conf := &mint.Config{
		ServerName:         "localhost",
		InsecureSkipVerify: true,
		SupportedVersions:  []mint.TLSVersion{mint.TLS13},
		CipherSuites:       mint.DefaultCipherSuites(),
		Enable0RTT:         true,
		AllowEarlyData:     true,
		EarlyDataLifetime:  600,
		PSKs:               cache,
		PSKModes:           []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
		SignatureSchemes:   []mint.SignatureScheme{mint.RSA_PKCS1_SHA256},
		Groups:             []mint.NamedGroup{mint.X25519},
		NextProtos:         []string{"h2"},
	}

	// === 1. Full Handshake ===
	log.Printf("[DEBUG][MAIN] cache-Pointer: %p", cache)
	log.Printf("[DEBUG][MAIN] conf.PSKs-Pointer: %p", conf.PSKs)

	log.Println("==> Full Handshake")
	raw1, err := net.Dial("tcp", "localhost:4444")
	if err != nil {
		log.Fatalf("Fehler beim Verbinden: %v", err)
	}
	client1 := mint.Client(raw1, conf)
	client1.Handshake()
	log.Println("==> vor dem Lesen der Handshake-Nachrichten")
	// --- Post-Handshake: NewSessionTickets abholen ---
	// --- Post-Handshake: NewSessionTicket abholen ---
	log.Printf("[DEBUG][MAIN] cache-Pointer: %p", cache)
	log.Printf("[DEBUG][MAIN] conf.PSKs-Pointer: %p", conf.PSKs)

	log.Println("==> vor dem Lesen der Handshake-Nachrichten")
	for {
		hm, err := client1.HsCtx().HIn().ReadMessage()
		if err != nil {
			log.Printf("Fehler beim Lesen der HandshakeMessage: %v", err)
			break
		}
		log.Printf("[PostHS] HandshakeMessage empfangen: Type=%d", hm.MsgType())
		if hm.MsgType() == mint.HandshakeTypeNewSessionTicket {
			log.Println("[PostHS] NewSessionTicket empfangen – breche Schleife ab")
			break
		}
	}
	log.Printf("PSKs nach Full Handshake: %+v", cache.Session)
	log.Printf("[DEBUG][MAIN] cache-Pointer: %p", cache)
	log.Printf("[DEBUG][MAIN] conf.PSKs-Pointer: %p", conf.PSKs)

	for k := range cache.Session {
		log.Printf("Cache-Key vorhanden: %q", k)
	}

	log.Println("==> vor closen des raw1")
	raw1.Close()

	log.Println("==> nach closen des raw1")

	// Log: Inhalt des PSK-Caches nach Full Handshake
	log.Printf("PSKs nach Full Handshake: %+v", cache.Dump())
	log.Printf("[DEBUG][MAIN] cache-Pointer: %p", cache)
	log.Printf("[DEBUG][MAIN] conf.PSKs-Pointer: %p", conf.PSKs)

	// Kurze Pause, damit Server ready ist
	time.Sleep(500 * time.Millisecond)

	// === 2. 0-RTT Handshake ===
	log.Println("==> 0-RTT Handshake")
	log.Printf("[DEBUG][MAIN] cache-Pointer: %p", cache)
	log.Printf("[DEBUG][MAIN] conf.PSKs-Pointer: %p", conf.PSKs)

	log.Printf("PSKs vor 0-RTT: %+v", cache.Dump())
	raw2, err := net.Dial("tcp", "localhost:4444")
	if err != nil {
		log.Fatalf("Fehler beim Verbinden: %v", err)
	}
	client2 := mint.Client(raw2, conf)
	client2.EarlyData = []byte("👋 EARLY DATA IM TEST!")
	client2.Handshake()
	log.Printf("Early Data: %+v", client2.EarlyData)
	log.Printf("[DEBUG][MAIN] cache-Pointer: %p", cache)
	log.Printf("[DEBUG][MAIN] conf.PSKs-Pointer: %p", conf.PSKs)

	raw2.Close()
}
