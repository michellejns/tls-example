package main

import (
	"crypto/rand"
	"crypto/sha256"
	"fmt"
	"io"
	"os"
	"time"

	"golang.org/x/crypto/curve25519"
	"golang.org/x/crypto/hkdf"
)

func main() {
	const n = 100

	// CSV-Datei anlegen
	file, err := os.Create("crypto_benchmark.csv")
	if err != nil {
		panic(err)
	}
	defer file.Close()

	// Kopfzeile
	fmt.Fprintln(file, "Run,ECDH_ms,HKDF_ms")

	for i := 1; i <= n; i++ {
		// --- ECDH: X25519 Keygen + Shared Secret ---
		startECDH := time.Now()
		var privKey, pubKey, peerPriv, peerPub, shared [32]byte

		_, _ = rand.Read(privKey[:])
		curve25519.ScalarBaseMult(&pubKey, &privKey)

		_, _ = rand.Read(peerPriv[:])
		curve25519.ScalarBaseMult(&peerPub, &peerPriv)

		curve25519.ScalarMult(&shared, &privKey, &peerPub)
		ecdhTime := float64(time.Since(startECDH).Microseconds()) / 1000.0

		// --- HKDF (SHA256) ---
		startHKDF := time.Now()
		h := hkdf.New(sha256.New, shared[:], nil, []byte("info"))
		buf := make([]byte, 32)
		_, err := io.ReadFull(h, buf)
		if err != nil {
			panic(err)
		}
		hkdfTime := float64(time.Since(startHKDF).Microseconds()) / 1000.0

		// Einzelwert in CSV speichern
		fmt.Fprintf(file, "%d,%.4f,%.4f\n", i, ecdhTime, hkdfTime)
	}

	fmt.Println("CSV-Export abgeschlossen: crypto_benchmark.csv")
}
