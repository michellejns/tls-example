package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"math"
	"os"
	"strconv"
	"strings"
)

type Stats struct {
	Label   string
	Samples []float64
	Mean    float64
	StdDev  float64
	Min     float64
	Max     float64
	Count   int
}

func fixNumberString(s string) string {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(s, ".") {
		return "0" + s
	}
	return s
}

func analyzeCSV(filename, label string) (*Stats, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	reader := csv.NewReader(file)
	reader.Comma = ';'
	records, err := reader.ReadAll()
	if err != nil {
		return nil, err
	}
	if len(records) < 2 {
		return nil, fmt.Errorf("zu wenige Daten in %s", filename)
	}
	var values []float64
	for i, row := range records[1:] { // Header überspringen
		if len(row) < 3 {
			continue
		}
		valstr := fixNumberString(row[2])
		val, err := strconv.ParseFloat(valstr, 64)
		if err != nil {
			log.Printf("Fehler in Zeile %d: %v (wert: %q)", i+2, err, valstr)
			continue
		}
		values = append(values, val)
	}
	if len(values) == 0 {
		return nil, fmt.Errorf("keine gültigen Daten in %s", filename)
	}

	sum := 0.0
	min := values[0]
	max := values[0]
	for _, v := range values {
		sum += v
		if v < min {
			min = v
		}
		if v > max {
			max = v
		}
	}
	mean := sum / float64(len(values))
	stddev := 0.0
	for _, v := range values {
		stddev += (v - mean) * (v - mean)
	}
	stddev = math.Sqrt(stddev / float64(len(values)))

	return &Stats{
		Label:   label,
		Samples: values,
		Mean:    mean,
		StdDev:  stddev,
		Min:     min,
		Max:     max,
		Count:   len(values),
	}, nil
}

func main() {
	files := []struct {
		filename string
		label    string
	}{
		/*{"benchmark_full.csv", "Full Handshake"},
		{"benchmark_1rtt.csv", "1-RTT"},
		{"benchmark_0rtt_no_replay.csv", "0-RTT (ohne Replay/Puncturing)"},
		{"benchmark_0rtt_replay.csv", "0-RTT (mit Replay/Puncturing)"},*/

		/*{"memory_benchmark_0rtt_replay.csv", "0-RTT (mit Replay/Puncturing)"},
		{"memory_benchmark_0rtt.csv", "0-RTT"},
		{"memory_benchmark_full.csv", "Full Handshake"},*/

		{"latency_benchmark.csv", "0-rtt Handshake (ohne Replay-Resistenz und Puncturing)"},
	}

	for _, entry := range files {
		fmt.Println("==================================================")
		fmt.Printf("Auswertung für: %s\n", entry.filename)
		stats, err := analyzeCSV(entry.filename, entry.label)
		if err != nil {
			fmt.Printf("Fehler: %v\n", err)
			continue
		}
		fmt.Printf("%s:\n", stats.Label)
		fmt.Printf("  Runs           : %d\n", stats.Count)
		fmt.Printf("  Mittelwert     : %.6f s\n", stats.Mean)
		fmt.Printf("  Standardabw.   : %.6f s\n", stats.StdDev)
		fmt.Printf("  Minimum        : %.6f s\n", stats.Min)
		fmt.Printf("  Maximum        : %.6f s\n", stats.Max)
	}
	fmt.Println("==================================================")
}
