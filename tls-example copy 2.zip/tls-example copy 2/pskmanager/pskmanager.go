package pskmanager

import (
	"log"
	"sync"
)

type UsedPSKManager struct {
	used map[string]bool
	mu   sync.Mutex
}

func NewUsedPSKManager() *UsedPSKManager {
	return &UsedPSKManager{
		used: make(map[string]bool),
	}
}

func (m *UsedPSKManager) IsUsed(pskHex string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.used[pskHex]
}

func (m *UsedPSKManager) MarkAsUsed(pskHex string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.used[pskHex] = true
	log.Printf("PSK %s als benutzt markiert (Replay-Resistenz)", pskHex)
}

var UsedPSKMgr = NewUsedPSKManager()
