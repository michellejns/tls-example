#!/bin/bash

RUNS=30
OUTFILE=benchmark_all_modes.csv

echo "Durchlauf;Typ;Dauer_s" > "$OUTFILE"

# 1. 30x Full Handshake
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (Full Handshake) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=full > client_log_full.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;Full;$DURATION" >> "$OUTFILE"
done

# 2. 30x 1-RTT (Initial handshake mit PSK-Erzeugung)
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (1-RTT) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=init > client_log_1rtt.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;1-RTT;$DURATION" >> "$OUTFILE"
done

# 3. 30x 0-RTT (ohne Replay-Detection, ohne Puncturing)
echo ">> Stelle sicher, dass Server und StateMachine ohne Replay/Puncturing laufen!"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (0-RTT ohne Replay/Puncturing) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=zeroRTTNoReplay > client_log_0rtt_norp.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;0-RTT_noReplayNoPuncture;$DURATION" >> "$OUTFILE"
done

# 4. 30x 0-RTT (mit Replay-Detection und Puncturing)
echo ">> Jetzt Server und StateMachine mit Replay/Puncturing starten!"
for i in $(seq 1 $RUNS)
do
    echo "======== Run $i (0-RTT mit Replay/Puncturing) ========"
    START=$(gdate +%s.%N)
    gtimeout 2s go run client/client.go --mode=zeroRTT > client_log_0rtt_rp.txt 2>&1
    END=$(gdate +%s.%N)
    DURATION=$(echo "$END - $START" | bc -l)
    echo "$i;0-RTT_ReplayPuncture;$DURATION" >> "$OUTFILE"
done

echo "Benchmark abgeschlossen. Ergebnisse in $OUTFILE"
